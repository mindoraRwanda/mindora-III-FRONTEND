# MINDORA frontend delivery

This archive contains the updated Next.js patient/therapist application and the supplied marketing-site source in a separate folder.

## Contents
- `Mindora_III-frontend-main/` — application frontend source.
- `website-source/mindora-website_v2-main/` — original official marketing website source, preserved separately; it is not merged into the application runtime.

## Start
1. Use Node.js 24.16.0 (see `.nvmrc`).
2. Enter `Mindora_III-frontend-main/`.
3. Copy `.env.example` to `.env.local` and set the environment's API gateway/socket URLs.
4. Run `npm ci`, then `npm run dev`.

See `Mindora_III-frontend-main/MINDORA_FRONTEND_DELIVERY_NOTES.md` for implementation notes and verification limitations.
